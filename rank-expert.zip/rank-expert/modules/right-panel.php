<?php
/**
 * 
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
?>

<div class="embox">
<div class="em-q">Short Code</div><hr>
<code>[RankExpert id=<?php echo wp_kses_post( $item_id);?>]</code>
</div>
<br/>
