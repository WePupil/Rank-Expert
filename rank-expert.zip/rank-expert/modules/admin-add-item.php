<?php
/**
 * 
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
?>

	<ul class="nav nav-tabs">
		<li class="active"><a href="#tab-1">Add Post ID</a></li>
	</ul>

	<div class="tab-content">
		<div id="tab-1" class="tab-pane active">
			
		<div class="Rexp-row "><div class="Rexp-input_group"><div class="Rexp-input_group_prepend">
		<div class="Rexp-input_group_text">Post ID</div></div>
		<input type="text" class="Rexp-input "  type="number" id="new_item_post_id"></div></div>

		<div class="Rexp-row" id="inputcheck"></div>

		<div class="Rexp-row" onclick="Rexp_add_item_button();">
		<button class="Rexp-btn Rexp-btn_secondary Rexp-btn_ls Rexp-add_answer">Add Item</button>
		</div>
		</div>

	</div>




                            