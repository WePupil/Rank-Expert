<?php
/**
 * 
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
?>

	<ul class="nav nav-tabs">
		<li class="active"><a href="#tab-1">Add Post ID</a></li>
		<li><a href="#tab-2">Add Url</a></li>
	</ul>

	<div class="tab-content">
		<div id="tab-1" class="tab-pane active">
			
		<div class="wpr-row "><div class="wpr-input_group"><div class="wpr-input_group_prepend">
		<div class="wpr-input_group_text">Post ID</div></div>
		<input type="text" class="wpr-input "  type="number" id="new_item_post_id"></div></div>

		<div class="wpr-row" id="inputcheck"></div>

		<div class="wpr-row" onclick="wpr_add_item_button();">
		<button class="wpr-btn wpr-btn_secondary wpr-btn_ls wpr-add_answer">Add Item</button>
		</div>
		</div>

		<div id="tab-2" class="tab-pane">
			
		<div class="wpr-row "><div class="wpr-input_group"><div class="wpr-input_group_prepend">
		<div class="wpr-input_group_text">URL</div></div>
		<input type="text" class="wpr-input " id="new_url"></div></div>

		<div class="wpr-row" id="inputcheck"></div>

		<div class="wpr-row" onclick="wpr_add_url_button();">
		<button class="wpr-btn wpr-btn_secondary wpr-btn_ls wpr-add_answer">Add URL</button>
		</div>
		</div>


	</div>




                            