=== Rank Expert - Rank and vote wp post by everyone ===
Contributors: wepupil
Tags: rank, ranker,ranking, vote
Requires at least: 5.0
Tested up to: 6.0.3
Requires PHP: 5.0
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Rank Expert is a wordpress plugin. Anyone can vote your selected post. Its easy to create and manage.

== Demo ==
 https://hitegg.com

== Shortcode Or Settings ==
- [Rank Expert]

== Feature ==
- Create a list of ranking.
- Add your posts as a ranking item.
- One way easy and fast insertion of posts.
- Your item will be rank as vote.
- Instant vote count by user.

== How to Integrate ==
- Create a list.
- Add post id (for find your post id install any plugin which shows post id)
- Set up your list.

== Style and Layout ==
- Most of the layout and styling have been from core WordPress CSS.
- All Frontend styles and layout has been tested using the WordPress TwentyTwenty theme.

== Frequently Asked Questions ==

= Are there restrictions and/or limitations to a Paid/Pro Version?  =

NO! This Plugin is completely Free.

= Are there restrictions for adding rank list/item? =

There is no limit to the number ofrank list/item. You can add as many rank list/item as you want.

= Can I embed a rank manually? =

Yes. Post the shortcode to any Post or Page: [RankExpert id=1], where id is the id of the Rank List.


== Screenshots ==
1. Front Page
2. List Page 
3. List Page 
4. Admin Page: All list
5. Admin Page: Create new list
6. Admin Page: Edit page view
7. Admin Page: Submit postid

== Changelog == 


Thank you
Wepupil Team
contact: wepupilteam@gmail.com