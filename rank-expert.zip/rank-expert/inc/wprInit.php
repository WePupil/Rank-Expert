<?php
/**
 * 
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc;

final class wprInit
{
	/**
	 * Store all the classes inside an array
	 * @return array Full list of classes
	 */
	public static function wpr_get_services() 
	{
		return [
			Pages\wprAdmin::class,
			Base\wprShortCode::class,
			Base\wprAdminEnqueue::class,
			Base\wprEnqueue::class,
			Base\wprSettingsLinks::class,
			Base\wprAjaxCall::class
		];
	}

	/**
	 * Loop through the classes, initialize them, 
	 * and call the register() method if it exists
	 * @return
	 */
	public static function wpr_register_services() 
	{
		foreach ( self::wpr_get_services() as $class ) {
			$service = self::wpr_instantiate( $class );
			if ( method_exists( $service, 'wpr_register' ) ) {
				$service->wpr_register();
			}
		}
	}

	/**
	 * Initialize the class
	 * @param  class $class    class from the services array
	 * @return class instance  new instance of the class
	 */
	private static function wpr_instantiate( $class )
	{
		$service = new $class();

		return $service;
	}
}