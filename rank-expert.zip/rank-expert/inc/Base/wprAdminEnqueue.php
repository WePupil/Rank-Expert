<?php 
/**
 *  enqueue scripts for admin
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc\Base;

use Inc\Base\wprBaseController;

/**
* 
*/
class wprAdminEnqueue extends wprBaseController
{
	public function wpr_register() {
		add_action( 'admin_enqueue_scripts', array( $this, 'wpr_admin_enqueue' ) );
	}
	
	function wpr_admin_enqueue() {
		// enqueue scripts for admin
		wp_register_style('wpr_admin_style', $this->plugin_url . 'assets/admin-style.css');
		wp_enqueue_style('wpr_admin_style');
		wp_enqueue_script('jquery');
		wp_enqueue_script( 'wpr_adminscript', $this->plugin_url . 'assets/admin-script.js' );
		wp_enqueue_script( 'wpr_tabscript', $this->plugin_url . 'assets/tabscript.js' );

		wp_localize_script( 'wpr_adminscript', 'wpr_adminajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));     

	}
} 