<?php 
/**
 * shortcode initialize
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc\Base;

use Inc\Base\wprBaseController;

/**
* 
*/
class wprShortCode extends wprBaseController
{
	public function wpr_register() {
		add_shortcode( 'rankexpert', array( $this, 'wpr_front_post_sc' ) );
	}
	
	function wpr_front_post_sc($atts, $content = null)
	{
		$a = shortcode_atts(array(
			'id' => '',
		), $atts);
		$list_id=$a['id'];
		require_once( "$this->plugin_path/templates/front-list.php" );
		return;
	}
}

