<?php 
/**
 *  enqueue Front page
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc\Base;

use Inc\Base\wprBaseController;

/**
* 
*/
class wprEnqueue extends wprBaseController
{
	public function wpr_register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'wpr_enqueue' ) );
	}
	
	function wpr_enqueue() {
		wp_enqueue_script('jquery');
		wp_enqueue_script( 'wpr_frontscript', $this->plugin_url . 'assets/front-script.js' );

		wp_localize_script( 'wpr_frontscript', 'wpr_frontajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));     
		 
	}
 


} 