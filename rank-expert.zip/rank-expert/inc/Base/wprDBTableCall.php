<?php 
/**
 * db table function
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc\Base;

/**
* 
*/
class wprDBTableCall
{

	public function wpr_posts_table(){
		global $wpdb;
		return $wpdb->prefix ."posts";
	}

    public function wpr_ranklist_table(){
		global $wpdb;
		return $wpdb->prefix ."wpr_ranklist";
	}
	public function wpr_rankitem_table(){
		global $wpdb;
		return $wpdb->prefix ."wpr_rankitem";
	}

}