<?php
/**
 *All link in plugins page initialize
 * @author WePupil<wepupilteam@gmail.com>
 * @version 1.0.0
 * @package RankExpert
 */
namespace Inc\Base;

use Inc\Base\wprBaseController;

class wprSettingsLinks extends wprBaseController
{
	public function wpr_register() 
	{
		add_filter( "plugin_action_links_$this->plugin", array( $this, 'wpr_settings_link' ) );
	}

	public function wpr_settings_link( $links ) 
	{
		$settings_link = '<a href="admin.php?page=rank-expert">Ranking List</a>';
		array_push( $links, $settings_link );
		return $links;
	}
}